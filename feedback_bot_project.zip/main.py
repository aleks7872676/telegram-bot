import os
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
ADMIN_CHAT_IDS = os.getenv("ADMIN_CHAT_IDS", "").split(",")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Привет! Я бот обратной связи. Напишите своё сообщение — и я передам его администрации."
    )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.message.from_user
    message_text = update.message.text
    for admin_id in ADMIN_CHAT_IDS:
        if admin_id:
            try:
                await context.bot.send_message(chat_id=admin_id, text=f"📩 Новое сообщение от @{user.username}:
{message_text}")
            except Exception as e:
                print(f"Ошибка отправки админу {admin_id}: {e}")

    await update.message.reply_text("✅ Спасибо! Ваше сообщение получено.")

def main():
    if not TOKEN:
        raise ValueError("❌ Ошибка: TELEGRAM_BOT_TOKEN не задан.")
    if not any(ADMIN_CHAT_IDS):
        raise ValueError("❌ Ошибка: ADMIN_CHAT_IDS не задан.")

    application = Application.builder().token(TOKEN).build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    print("🤖 Бот запущен...")
    application.run_polling()

if __name__ == "__main__":
    main()